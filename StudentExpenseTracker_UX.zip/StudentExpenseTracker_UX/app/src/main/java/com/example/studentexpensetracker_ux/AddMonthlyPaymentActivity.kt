package com.example.studentexpensetracker_ux

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class AddMonthlyPaymentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_monthly_payment)
        
        setupButtons()
        setupBottomNavigation()
    }
    
    private fun setupButtons() {
        findViewById<View>(R.id.backArrow).setOnClickListener {
            finish()
        }
        
        findViewById<View>(R.id.addButton).setOnClickListener {
            val name = findViewById<EditText>(R.id.paymentNameInput).text.toString()
            val amountStr = findViewById<EditText>(R.id.amountInput).text.toString()
            val dueDate = findViewById<EditText>(R.id.dueDateInput).text.toString()
            
            if (name.isNotEmpty() && amountStr.isNotEmpty() && dueDate.isNotEmpty()) {
                val amount = amountStr.toDoubleOrNull() ?: 0.0
                val payment = MonthlyPayment(name, amount, dueDate)
                DataManager.addMonthlyPayment(payment)
                
                val intent = Intent(this, PaymentSuccessActivity::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
    
    private fun setupBottomNavigation() {
        findViewById<View>(R.id.homeTab).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.monthlyTab).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.dailyTab).setOnClickListener {
            val intent = Intent(this, DailyExpensesActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}