package com.example.studentexpensetracker_ux

data class MonthlyPayment(val name: String, val amount: Double, val dueDate: String)
data class DailyExpense(val name: String, val amount: Double, val category: String)

object DataManager {
    val monthlyPayments = mutableListOf<MonthlyPayment>(
        MonthlyPayment("Netflix", 18.99, "1st"),
        MonthlyPayment("Rent", 1700.00, "17th"),
        MonthlyPayment("Phone Plan", 45.00, "Rogers")
    )

    val dailyExpenses = mutableListOf<DailyExpense>(
        DailyExpense("Uber", 15.00, "Transport"),
        DailyExpense("Dairy Queen", 8.99, "Food"),
        DailyExpense("Gas", 25.00, "Transport")
    )
    
    fun addMonthlyPayment(payment: MonthlyPayment) {
        monthlyPayments.add(payment)
    }
    
    fun removeMonthlyPayment(payment: MonthlyPayment) {
        monthlyPayments.remove(payment)
    }
    
    fun addDailyExpense(expense: DailyExpense) {
        dailyExpenses.add(expense)
    }
    
    fun getTotalMonthlyExpenses(): Double {
        return monthlyPayments.sumOf { it.amount }
    }
    
    fun getTotalDailyExpenses(): Double {
        return dailyExpenses.sumOf { it.amount }
    }
}