package com.example.studentexpensetracker_ux

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DailyExpensesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_daily_expenses)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.dailyExpensesLayout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        setupButtons()
        setupListItems()
        setupBottomNavigation()
        updateDailySummary()
    }
    
    private fun setupButtons() {
        findViewById<View>(R.id.backArrow).setOnClickListener {
            finish()
        }
        
        findViewById<View>(R.id.addDailyExpenseButton).setOnClickListener {
            val intent = Intent(this, AddDailyExpenseActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun setupListItems() {
        val expenseScrollView = findViewById<android.widget.ScrollView>(R.id.expenseScrollView)
        val parentLayout = expenseScrollView.getChildAt(0) as LinearLayout
        
        // Remove existing hardcoded items
        parentLayout.removeAllViews()
        
        for (expense in DataManager.dailyExpenses) {
            val row = createExpenseRow(expense)
            parentLayout.addView(row)
        }
    }
    
    private fun createExpenseRow(expense: DailyExpense): LinearLayout {
        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
            // Margin bottom 8dp
            val params = layoutParams as LinearLayout.LayoutParams
            params.bottomMargin = dpToPx(8)
            layoutParams = params
        }
        
        // Left part (Name & Category)
        val leftLayout = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            orientation = LinearLayout.VERTICAL
        }
        
        val nameTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            text = expense.name
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        leftLayout.addView(nameTv)
        
        val categoryTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            text = expense.category
            setTextColor(Color.parseColor("#808080")) // gray_text
            textSize = 12f
            // margin top 4dp
            val params = layoutParams as LinearLayout.LayoutParams
            params.topMargin = dpToPx(4)
            layoutParams = params
        }
        leftLayout.addView(categoryTv)
        
        row.addView(leftLayout)
        
        // Right part (Amount & Category/Type label repeated in original? Let's match original)
        // Original XML had "Transport" or "Food" under amount too.
        val rightLayout = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        
        val amountTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            text = "$" + String.format("%.2f", expense.amount)
            setTextColor(Color.parseColor("#4CAF50")) // green_primary
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        rightLayout.addView(amountTv)
        
        val typeTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            text = expense.category // Reusing category here as per design pattern
            setTextColor(Color.parseColor("#808080")) // gray_text
            textSize = 12f
            val params = layoutParams as LinearLayout.LayoutParams
            params.topMargin = dpToPx(4)
            layoutParams = params
        }
        rightLayout.addView(typeTv)
        
        row.addView(rightLayout)
        
        return row
    }
    
    private fun updateDailySummary() {
        val totalSpent = DataManager.getTotalDailyExpenses()
        val dailyBudget = 200.0 // Hardcoded assumption
        val remaining = dailyBudget - totalSpent
        
        val summaryLayout = findViewById<LinearLayout>(R.id.dailySummary)
        val amountsRow = summaryLayout.getChildAt(1) as LinearLayout
        
        // Spent (Left)
        val spentLayout = amountsRow.getChildAt(0) as LinearLayout
        val spentTv = spentLayout.getChildAt(0) as TextView
        spentTv.text = "$" + String.format("%.2f", totalSpent)
        
        // Remaining (Right)
        val remainingLayout = amountsRow.getChildAt(1) as LinearLayout
        val remainingTv = remainingLayout.getChildAt(0) as TextView
        remainingTv.text = "$" + String.format("%.2f", remaining)
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }
    
    private fun setupBottomNavigation() {
        findViewById<View>(R.id.homeTab).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.monthlyTab).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.dailyTab).setOnClickListener {
            // Already on daily page
        }
    }
}