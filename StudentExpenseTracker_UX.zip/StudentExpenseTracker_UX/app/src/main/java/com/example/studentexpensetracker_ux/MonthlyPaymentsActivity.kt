package com.example.studentexpensetracker_ux

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MonthlyPaymentsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_monthly_payments)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.monthlyPaymentsLayout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        setupButtons()
        setupListItems()
        setupBottomNavigation()
        updateFinancialSummary()
    }
    
    private fun setupButtons() {
        findViewById<View>(R.id.backArrow).setOnClickListener {
            finish()
        }
        
        findViewById<View>(R.id.addPaymentButton).setOnClickListener {
            val intent = Intent(this, AddMonthlyPaymentActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun setupListItems() {
        val tableScrollView = findViewById<android.widget.ScrollView>(R.id.tableScrollView)
        val parentLayout = tableScrollView.getChildAt(0) as LinearLayout
        
        // Keep the header row (index 0) and remove the rest (dummy data)
        if (parentLayout.childCount > 1) {
            parentLayout.removeViews(1, parentLayout.childCount - 1)
        }
        
        for (payment in DataManager.monthlyPayments) {
            val row = createPaymentRow(payment)
            parentLayout.addView(row)
        }
    }
    
    private fun createPaymentRow(payment: MonthlyPayment): LinearLayout {
        val row = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#F5F5F5")) // table_row_gray
            setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12))
            weightSum = 4f
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val intent = Intent(this@MonthlyPaymentsActivity, MonthlyPaymentDetailActivity::class.java)
                startActivity(intent)
            }
        }

        // Name
        val nameTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.5f)
            text = payment.name
            setTextColor(Color.BLACK)
            textSize = 14f
        }
        row.addView(nameTv)

        // Amount
        val amountTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = String.format("%.2f", payment.amount)
            setTextColor(Color.BLACK)
            textSize = 14f
            gravity = Gravity.CENTER
        }
        row.addView(amountTv)

        // Due Date
        val dateTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            text = payment.dueDate
            setTextColor(Color.BLACK)
            textSize = 14f
            gravity = Gravity.CENTER
        }
        row.addView(dateTv)

        // Delete/X
        val xTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.5f)
            text = "X"
            setTextColor(Color.BLACK)
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener {
                // Remove from DataManager
                DataManager.removeMonthlyPayment(payment)
                // Remove the row from the view
                (row.parent as? LinearLayout)?.removeView(row)
                // Update summary
                updateFinancialSummary()
            }
        }
        row.addView(xTv)

        return row
    }
    
    private fun updateFinancialSummary() {
        val totalExpenses = DataManager.getTotalMonthlyExpenses()
        val monthlyIncome = 3000.0 // Hardcoded for now as in layout
        val remaining = monthlyIncome - totalExpenses

        val summaryLayout = findViewById<LinearLayout>(R.id.financialSummary)
        
        // Total Expenses Value
        val expensesRow = summaryLayout.getChildAt(0) as LinearLayout
        val expensesTv = expensesRow.getChildAt(1) as TextView
        expensesTv.text = "$" + String.format("%.2f", totalExpenses)
        
        // Remaining Value
        val remainingRow = summaryLayout.getChildAt(2) as LinearLayout
        val remainingTv = remainingRow.getChildAt(1) as TextView
        remainingTv.text = "$" + String.format("%.2f", remaining)
    }
    
    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }
    
    private fun setupBottomNavigation() {
        findViewById<View>(R.id.homeTab).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.monthlyTab).setOnClickListener {
            // Already on monthly page
        }
        
        findViewById<View>(R.id.dailyTab).setOnClickListener {
            val intent = Intent(this, DailyExpensesActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}