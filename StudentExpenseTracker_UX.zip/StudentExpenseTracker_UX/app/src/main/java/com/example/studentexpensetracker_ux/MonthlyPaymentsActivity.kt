package com.example.studentexpensetracker_ux

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.view.View

class MonthlyPaymentsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_monthly_payments)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.monthlyPaymentsLayout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        setupButtons()
        setupListItems()
        setupBottomNavigation()
    }
    
    private fun setupButtons() {
        findViewById<View>(R.id.backArrow).setOnClickListener {
            finish()
        }
        
        findViewById<View>(R.id.addPaymentButton).setOnClickListener {
            val intent = Intent(this, AddMonthlyPaymentActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun setupListItems() {
        findViewById<View>(R.id.rowNetflix).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentDetailActivity::class.java)
            startActivity(intent)
        }
        
        findViewById<View>(R.id.rowRent).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentDetailActivity::class.java)
            startActivity(intent)
        }
        
        findViewById<View>(R.id.rowPhone).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentDetailActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun setupBottomNavigation() {
        findViewById<View>(R.id.homeTab).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.monthlyTab).setOnClickListener {
            // Already on monthly page, do nothing
        }
        
        findViewById<View>(R.id.dailyTab).setOnClickListener {
            val intent = Intent(this, DailyExpensesActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}