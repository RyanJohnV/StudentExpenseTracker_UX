package com.example.studentexpensetracker_ux

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MonthlyPaymentDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monthly_payment_detail)

        setupButtons()
        setupBottomNavigation()
    }

    private fun setupButtons() {
        findViewById<View>(R.id.backArrow).setOnClickListener {
            finish()
        }
        
        findViewById<View>(R.id.addPaymentButton).setOnClickListener {
            val intent = Intent(this, AddMonthlyPaymentActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupBottomNavigation() {
        findViewById<View>(R.id.homeTab).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        findViewById<View>(R.id.monthlyTab).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        findViewById<View>(R.id.dailyTab).setOnClickListener {
            val intent = Intent(this, DailyExpensesActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}