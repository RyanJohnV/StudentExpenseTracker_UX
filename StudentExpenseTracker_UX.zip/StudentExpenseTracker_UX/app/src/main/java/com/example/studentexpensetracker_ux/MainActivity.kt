package com.example.studentexpensetracker_ux

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        setupBottomNavigation()
        setupMonthlyIncomeCard()
    }
    
    private fun setupMonthlyIncomeCard() {
        findViewById<View>(R.id.monthlyIncomeCard).setOnClickListener {
            val intent = Intent(this, AddMonthlyIncomeActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun setupBottomNavigation() {
        findViewById<View>(R.id.homeTab).setOnClickListener {
            // Already on home page, do nothing
        }
        
        findViewById<View>(R.id.monthlyTab).setOnClickListener {
            val intent = Intent(this, MonthlyPaymentsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
        
        findViewById<View>(R.id.dailyTab).setOnClickListener {
            val intent = Intent(this, DailyExpensesActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }
}